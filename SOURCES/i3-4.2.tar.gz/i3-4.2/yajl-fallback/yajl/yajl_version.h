#ifndef YAJL_VERSION_H_
#define YAJL_VERSION_H_
/* Fallback for libyajl 1 which does not provide yajl_version.h */
#define YAJL_MAJOR 1
#define YAJL_MINOR 0
#define YAJL_MICRO 0
#endif
