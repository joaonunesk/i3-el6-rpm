#!/bin/sh
#echo '{"version":1}'
echo '['
while :; do
	echo '[{"full_text": "this is a test", "color":"#FF0000"}, {"full_text": "haha", "color":"#00FF00"}],'
	sleep 1
done
